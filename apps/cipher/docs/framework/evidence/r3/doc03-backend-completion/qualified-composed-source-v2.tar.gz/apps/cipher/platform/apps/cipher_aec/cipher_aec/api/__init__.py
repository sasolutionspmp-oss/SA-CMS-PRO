"""Versioned product API boundary."""
